import asyncio
import os
import random
import re
from dataclasses import dataclass
from pathlib import Path

import yaml
from dotenv import load_dotenv
from playwright.async_api import async_playwright, Page

ROOT = Path(__file__).resolve().parent


@dataclass
class Settings:
    server: str
    username: str
    password: str
    dry_run: bool
    headless: bool
    min_delay: float
    max_delay: float
    cycle_minutes: float
    village_id: int | None
    features: dict
    build_queue: list
    farm_lists: list


def load_settings() -> Settings:
    load_dotenv(ROOT / '.env')
    cfg = yaml.safe_load((ROOT / 'config.yaml').read_text(encoding='utf-8'))
    server = os.getenv('TRAVIAN_SERVER', '').rstrip('/')
    username = os.getenv('TRAVIAN_USERNAME', '')
    password = os.getenv('TRAVIAN_PASSWORD', '')
    if not server or not username or not password:
        raise SystemExit('Set TRAVIAN_SERVER, TRAVIAN_USERNAME and TRAVIAN_PASSWORD in .env')
    return Settings(
        server=server,
        username=username,
        password=password,
        dry_run=bool(cfg.get('dry_run', True)),
        headless=bool(cfg.get('headless', False)),
        min_delay=float(cfg.get('min_delay_seconds', 2.5)),
        max_delay=float(cfg.get('max_delay_seconds', 6.5)),
        cycle_minutes=float(cfg.get('cycle_minutes', 10)),
        village_id=cfg.get('village_id'),
        features=cfg.get('features', {}),
        build_queue=cfg.get('build_queue', []),
        farm_lists=cfg.get('farm_lists', []),
    )


class TravianBot:
    def __init__(self, page: Page, s: Settings):
        self.page = page
        self.s = s

    async def jitter(self, low=None, high=None):
        await asyncio.sleep(random.uniform(low or self.s.min_delay, high or self.s.max_delay))

    async def goto(self, path: str):
        url = path if path.startswith('http') else f'{self.s.server}/{path.lstrip("/")}'
        await self.page.goto(url, wait_until='domcontentloaded')
        await self.jitter(0.7, 1.8)

    async def login(self):
        await self.goto('/login.php')
        # Travian has used both name/password and email/password variants.
        user = self.page.locator('input[name="name"], input[name="email"], input[type="email"]').first
        pwd = self.page.locator('input[name="password"], input[type="password"]').first
        if await user.count() and await pwd.count():
            await user.fill(self.s.username)
            await pwd.fill(self.s.password)
            await self.jitter(0.4, 1.1)
            submit = self.page.locator('button[type="submit"], input[type="submit"]').first
            if not await submit.count():
                raise RuntimeError('Login submit button not found.')
            await submit.click()
            await self.page.wait_for_load_state('domcontentloaded')
        # If already authenticated, /login.php may redirect directly into the game.
        if 'login' in self.page.url.lower():
            body = (await self.page.locator('body').inner_text()).lower()
            if 'password' in body and ('login' in body or 'sign in' in body):
                raise RuntimeError('Login did not complete. CAPTCHA/2FA/lobby selection may require manual action.')
        print(f'[OK] Logged in: {self.page.url}')

    async def select_village(self):
        if self.s.village_id is None:
            return
        # d=<village id> is supported by many Travian game pages.
        await self.goto(f'/dorf1.php?newdid={self.s.village_id}')

    async def read_resources(self):
        await self.goto('/dorf1.php')
        result = {}
        selectors = {
            'wood': '#l1, #stockBarResource1',
            'clay': '#l2, #stockBarResource2',
            'iron': '#l3, #stockBarResource3',
            'crop': '#l4, #stockBarResource4',
        }
        for name, selector in selectors.items():
            loc = self.page.locator(selector).first
            if await loc.count():
                text = (await loc.inner_text()).strip().replace(',', '').replace('.', '')
                m = re.search(r'-?\d+', text)
                result[name] = int(m.group()) if m else text
        print('[RESOURCES]', result or 'Could not detect stock-bar selectors')
        return result

    async def try_build_slot(self, slot_id: int, desired_level: int | None = None):
        await self.goto(f'/build.php?id={slot_id}')
        title = ''
        h1 = self.page.locator('h1').first
        if await h1.count():
            title = (await h1.inner_text()).strip()
        level_match = re.search(r'(?:Level|level)\s*(\d+)', title)
        current = int(level_match.group(1)) if level_match else None
        if desired_level is not None and current is not None and current >= desired_level:
            print(f'[BUILD] slot {slot_id}: already level {current} (target {desired_level})')
            return False

        btn = self.page.locator(
            'button.green.build, button.textButtonV1.green, '
            'button:has-text("Upgrade"), button:has-text("Build"), '
            'input[type="submit"][value*="Build"]'
        ).first
        if not await btn.count():
            print(f'[BUILD] slot {slot_id}: no available build/upgrade button')
            return False

        label = (await btn.inner_text()).strip() if await btn.evaluate('(e)=>e.tagName') == 'BUTTON' else 'Build'
        if self.s.dry_run:
            print(f'[DRY RUN] Would click {label!r} for slot {slot_id}; page title={title!r}')
            return True
        await btn.click()
        await self.page.wait_for_load_state('domcontentloaded')
        print(f'[BUILD] Clicked build/upgrade for slot {slot_id}')
        return True

    async def run_build_queue(self):
        for item in self.s.build_queue:
            slot = int(item['target'])
            desired = item.get('desired_level')
            acted = await self.try_build_slot(slot, int(desired) if desired is not None else None)
            if acted and not self.s.dry_run:
                break  # normally one new construction action per cycle
            await self.jitter()

    async def send_farm_list(self, list_id: int):
        # Current Travian farm lists are accessed through Rally Point tt=99.
        await self.goto('/build.php?gid=16&tt=99')
        candidates = [
            f'button[data-listid="{list_id}"]',
            f'button[name="startRaid"][value="{list_id}"]',
            f'#raidList{list_id} button:has-text("Start")',
            f'[data-list-id="{list_id}"] button:has-text("Start")',
        ]
        btn = None
        for selector in candidates:
            loc = self.page.locator(selector).first
            if await loc.count():
                btn = loc
                break
        if btn is None:
            print(f'[FARM] list {list_id}: send button not detected; selector may need adapting')
            return False
        if self.s.dry_run:
            print(f'[DRY RUN] Would send farm list {list_id}')
            return True
        await btn.click()
        print(f'[FARM] Sent farm list {list_id}')
        return True

    async def run_once(self):
        await self.select_village()
        if self.s.features.get('collect_resources', True):
            await self.read_resources()
        if self.s.features.get('build_queue', True):
            await self.run_build_queue()
        if self.s.features.get('farm_lists', False):
            for list_id in self.s.farm_lists:
                await self.send_farm_list(int(list_id))
                await self.jitter()


async def main():
    s = load_settings()
    async with async_playwright() as p:
        browser = await p.chromium.launch(headless=s.headless)
        context = await browser.new_context(viewport={'width': 1440, 'height': 1000})
        page = await context.new_page()
        bot = TravianBot(page, s)
        try:
            await bot.login()
            while True:
                try:
                    await bot.run_once()
                except Exception as exc:
                    print(f'[ERROR] cycle failed: {exc}')
                    await page.screenshot(path=str(ROOT / 'last_error.png'), full_page=True)
                if s.cycle_minutes <= 0:
                    break
                delay = s.cycle_minutes * 60 + random.uniform(-30, 30)
                print(f'[WAIT] Next cycle in about {max(1, delay/60):.1f} min')
                await asyncio.sleep(max(1, delay))
        finally:
            await context.storage_state(path=str(ROOT / 'session.json'))
            await browser.close()


if __name__ == '__main__':
    asyncio.run(main())
